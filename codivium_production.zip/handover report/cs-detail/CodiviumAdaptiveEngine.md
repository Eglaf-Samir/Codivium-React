# CodiviumAdaptiveEngine.cs — Detail Reference

## What it is
Seven-step recommendation engine for the Adaptive Practice page.
Stateless — takes session history in, produces recommendation state out.

## Entry Point
```csharp
AdaptiveEngineResult AdaptiveEngine.Compute(
    string track,
    IReadOnlyList<CodiviumScoring.CodingSession> codingSessions,
    IReadOnlyList<CodiviumScoring.McqAttempt>    mcqAttempts,
    DateTimeOffset asOfUtc
)
```

## Input
| Parameter | Type | Notes |
|---|---|---|
| track | string | "micro" or "interview" — determines which session set is primary |
| codingSessions | CodingSession[] | 365-day window for the specified track |
| mcqAttempts | McqAttempt[] | 365-day window, all MCQ |
| asOfUtc | DateTimeOffset | Reference timestamp (use DateTimeOffset.UtcNow) |

## Output: AdaptiveEngineResult
| Field | Type | Notes |
|---|---|---|
| IsNewUser | bool | True → caller returns 404 → orientation mode |
| Mode | string | "orientation"/"building"/"full" |
| SessionCount | int | Total sessions |
| LastSessionDaysAgo | int | Days since most recent session |
| LastSessionLabel | string | Human-readable: "yesterday", "3 days ago" |
| Categories | AdaptiveCategoryDto[] | Ring state per category |
| Primary | AdaptivePrimaryDto? | Highest-priority recommendation |
| Alternatives | AdaptiveAlternativeDto[] | Up to 2 secondary recommendations |
| Milestone | AdaptiveMilestoneDto? | Null if no milestone fires |
| RecentSessions | AdaptiveRecentSessionDto[] | Last 5 sessions |
| SessionQuality | AdaptiveSessionQualityDto | Foundation/Consolidation/Proficient/Fluent level |

## Seven Steps
1. New-user detection (no sessions → IsNewUser=true)
2. Mode calculation (total < 10 → "building", else "full")
3. Ring fill computation (correct/30 × 100, with grace period drain)
4. Ring state classification (ready/gap/draining/locked/normal)
5. Session quality evaluation (accuracy + peek rate + response time)
6. Trigger evaluation — 8 recommendation types in priority order
7. Milestone detection (first session, first ring, 10 sessions, first week)

## Recommendation Trigger Thresholds (constants in class)
| Trigger | Key threshold |
|---|---|
| re_entry | >7 days absent |
| weakness_spotlight | Gap ≥50%, ≥3 categories known, ≥5 questions |
| spaced_review | ≥14 days since last correct, ≥5 correct |
| difficulty_progression | Fill ≥100%, rolling ≥70%, ≥3 sessions |
| mode_switch | MCQ:coding ratio >1.5 or <0.67, ≥10 sessions |
| stretch | Score ≥65% in current category, adjacent untouched exists |
| milestone | First session / first ring / 10 sessions / first week |
| recovery | Score drop ≥30% within 3 days |

## Used by
CodiviumAdaptiveEndpoints.cs → GetAdaptiveState()

## Limitations
- SubCategory field on CodingSession required for stretch recommendations
- All thresholds are hardcoded constants — not read from config file
- Track parameter determines which codingSessions subset is used; mcqAttempts are always all-MCQ
