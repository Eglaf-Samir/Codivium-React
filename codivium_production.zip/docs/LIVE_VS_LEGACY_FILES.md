# Live vs Legacy / Generated Files

This document classifies every file in the package by its live/reference/generated status.
It is the authoritative reference for "what to deploy, what to edit, what to ignore."

> **See also:** `package/getting-started/HANDOVER.md` (project root) for the full architecture reference, state model, and integration notes.
> This document covers file classification only.

**Last updated:** 2026-03-13 (CVU-2026-03-AH)

---

## LIVE — Deploy these

### Frontend CSS

The canonical CSS strategy is **8 split files** loaded by all supported entry pages in this order:

| File | Owns |
|---|---|
| `assets/components/core/base.css` | Tokens, resets, shared button surface (`--cvbtn-*`) |
| `assets/components/sidebar/menu-overrides.css` | Grid-scroll, stage layout overrides |
| `assets/components/dashboard/dashboard.base.css` | Dashboard tokens + typography |
| `assets/components/dashboard/dashboard.shell.css` | Stage, insights-layout, insights-form base |
| `assets/components/dashboard/dashboard.resizers.css` | Splitter visuals |
| `assets/components/dashboard/dashboard.layout.css` | Grid geometry, mode visibility, breakpoints |
| `assets/components/dashboard/dashboard.panels.css` | Panel internals, chart controls, scores expanded |
| `assets/components/dashboard/dashboard.chrome.css` | Preset dock, toolbar buttons |
| `assets/components/dashboard/dashboard.modals.css` | Modal overlays |
| `assets/components/dashboard/dashboard.math.css` | KaTeX equation styling |


### Frontend JS (generated — deploy this)

| File | Role |
|---|---|
| `assets/components/dashboard/js/dashboard.bundle.js` | **Deploy this. Never hand-edit.** Built by `scripts/build_dashboard_bundle.sh`. |

### Frontend JS sources (live — edit these, not the bundle)

| File | Role |
|---|---|
| `assets/components/dashboard/js/dashboard.00.config.js` | Constants and configuration |
| `assets/components/dashboard/js/dashboard.00.core.js` | UI state, layout engine, presets, dock, resize |
| `assets/components/dashboard/js/dashboard.01.scoreinfo.js` | Score info panel content |
| `assets/components/dashboard/js/dashboard.02.heatmap-analysis.js` | Heatmap analysis |
| `assets/components/dashboard/js/dashboard.03.time-analysis.js` | Time-on-platform analysis |
| `assets/components/dashboard/js/dashboard.04.exercise-analysis.js` | Exercise / treemap analysis |
| `assets/components/dashboard/js/dashboard.05.overview-analysis.js` | Overview / summary analysis |
| `assets/components/dashboard/js/dashboard.06.mcq-and-render.js` | MCQ charts, all chart rendering |
| `assets/components/dashboard/js/dashboard.06b.refresh.js` | `CodiviumInsights` public API, resilience |
| `assets/components/dashboard/js/dashboard.07.tour.js` | Guided tour |
| `assets/components/dashboard/js/dashboard.08.help-and-init.js` | FAQ, glossary, `init()` entry point |
| `assets/components/dashboard/js/dashboard_settings.js` | Settings page helper (settings page only) |

### Other frontend assets

| File | Role |
|---|---|
| `assets/components/core/polyfill-loader.js` | Script loader — loads bundle + Chart.js + KaTeX in sequence |
| `assets/components/core/polyfills.js` | Browser polyfills |
| `assets/components/core/global.js` | Global helpers |
| `assets/components/core/telemetry.js` | Telemetry stub |
| `assets/components/logo/` | Logo / brand-cube component |
| `assets/components/sidebar/` | Sidebar component |
| `assets/components/topbar/` | Topbar component |
| `assets/favicons/` | Favicons and webmanifest |
| `assets/components/dashboard/dashboard_settings.css` | Settings page styles (settings page only) |

### Vendor assets

| Status | Detail |
|---|---|
| `assets/vendor/` | Contains `README_VENDOR.txt` only. **No actual vendor files are committed.** |
| Chart.js | Loaded by `polyfill-loader.js`: local `assets/vendor/chartjs/chart.umd.min.js` (if present after running `fetch_vendor_deps.sh`), then CDN fallback |
| KaTeX | Loaded by `polyfill-loader.js`: local `assets/vendor/katex/` → CDN fallback |

### Backend

| File | Role |
|---|---|
| `backend/CodiviumDashboardBackend_AllInOne_v38.cs` | All-in-one backend: DTOs, calculators, MCQ builder (**LIVE**) |
| `backend/CodiviumDashboardPayloadV2Adapter.v1.cs` | Composes v38 into `dashboard-payload-v2` shape (**LIVE**) |
| `backend/CodiviumDashboardUiPrefs.v1.cs` | UI prefs model + store abstraction (**LIVE**) |
| `backend/CodiviumHeatmapFocusBuilder.v1.cs` | Heatmap focus rankings builder (**LIVE**) |
| `backend/CodiviumInsights.v1.cs` | Insights/analysis builders (**LIVE**) |
| `backend/CodiviumRecommendedActions.v1.cs` | CTA builder (**LIVE**) |
| `backend/CodiviumRawDataBuilder.v1.cs` | Raw data construction helpers (**LIVE**) |
| `backend/CodiviumKatexScoring.v1.cs` | KaTeX-aligned scoring (**LIVE**) |
| `backend/CodiviumKatexConfig.v1.cs` | KaTeX config loader (**LIVE**) |
| `backend/CodiviumClock.v1.cs` | Injected clock for deterministic time (**LIVE**) |
| `backend/CodiviumConfigValidation.v1.cs` | Config validation (**LIVE**) |
| `backend/CodiviumJsonConverters.v1.cs` | JSON converters (**LIVE**) |
| `backend/CodiviumPoints.v1.cs` | **TOMBSTONE STUB** — 5-line comment only; no real code. Do not compile or deploy as a logic file. |
| `backend/api/Program.cs` | Example API endpoints (REFERENCE — replace in production) |
| `backend/api/Services/` | Example services (REFERENCE — replace in production) |
| `config/scoring-config.v1.json` | Scoring configuration |
| `config/scoring-config.katex.v1.json` | KaTeX scoring weights |

### Entry pages (live)

| File | Purpose | Notes |
|---|---|---|
| `codivium_insights_embedded.html` | Production integration entry point | Demo data script is commented out. Ready for integration. |
| `dashboard_view_settings.html` | UI prefs settings page | OK |
| `join.html`, `login.html`, `mcq-parent.html` | Root-level app-shell stubs | Intentional placeholder pages |

---

## DEMO — Not deployed to production

| File / Dir | Role |
|---|---|
| `demo/codivium_insights_demo_*.html` | Per-preset demo pages |
| `demo/demo_data_*.js` | Static demo payloads |
| `demo/join.html`, `demo/login.html`, `demo/mcq-parent.html` | Demo context stubs (use `../assets/` relative paths) |
| `demo/payload_example1.json` | Example payload (reference) |

---

## REFERENCE / LEGACY — Do not deploy

| File | Reason |
|---|---|
| `backend/CodiviumScoringEngine.cs` | **COMPILED — active scoring engine.** Provides `CodiviumScoring`, `CodiviumRawData`, `ComputeScoreBundle()`. New scoring logic goes in `CodiviumKatexScoring.v1.cs`. |
| `backend/McqPayloadCallExample.v1.cs` | Integration example only; not production code. |

---

---

## GENERATED — Never hand-edit

| File | How to regenerate |
|---|---|
| `assets/components/dashboard/js/dashboard.bundle.js` | `bash scripts/build_dashboard_bundle.sh` |
| `RELEASE_MANIFEST.json` | `node scripts/generate_manifest.js` |

---

## DOCS / BUILD TOOLS — Not deployed to production

`contracts/`, `docs/`, `csp/`, `scripts/`, `tests/`, `package/getting-started/HANDOVER.md`, `package/history/CHANGELOG.md`,
`package/operations/DEPLOYMENT_GUIDE.md`, and all other Markdown files are developer documentation and
build tooling only. Do not deploy to production servers.

---

## Editor / Workspace files

### Runtime (active page files — these run when editor.html is loaded)

| File | Status | Notes |
|---|---|---|
| `editor.html` | DEMO/PROTOTYPE | Page HTML shell; not production-ready |
| `assets/components/editor/editor-page.js` | DEMO/PROTOTYPE | **Active runtime** — all workspace JS in one file |
| `assets/components/editor/editor-page.css` | DEMO/PROTOTYPE | **Active styles** — all workspace CSS in one file |

### Not yet active (reference / integration layer)

| File | Status | Notes |
|---|---|---|
| `assets/components/editor/editor-page.js` | **DEPLOYED** | Active workspace runtime — loaded by editor.html. Owns UI, load, and submit. |
| `assets/components/editor/editor-page.state-model.js` | REFERENCE | State layer documentation — read-only |
| `assets/components/editor/editor-page.js` | REFERENCE | Split JS modules (source for future modularisation) |
| `assets/components/editor/editor-page.css` | REFERENCE | Split CSS modules |

### One-sentence summary
**The active page runtime is `editor-page.js` + `editor-page.css`. Both are loaded by `editor.html`. `editor-page.state-model.js` is read-only state documentation.**

