#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Ensure the shipped dashboard.bundle.js matches the module sources
bash "$ROOT_DIR/scripts/build_dashboard_bundle.sh" >/dev/null

node "$ROOT_DIR/scripts/smoke_test.js"

# JS unit tests (45+ tests covering state, prefs, CTAs, selectedTrack, debug flag)
node --test "$ROOT_DIR/tests/dashboard.test.js"

# Contract validation (schema subset) for demo payload fixtures
node "$ROOT_DIR/scripts/validate_payload_contract.js"

# Validate bundle syntax with node's parser
node --check "$ROOT_DIR/assets/components/dashboard/js/dashboard.bundle.js" >/dev/null

# Security gates (strict CSP friendliness)
# Call via bash so the check suite works even if executable bits are lost
# when the package is extracted on some platforms.
bash "$ROOT_DIR/scripts/security_gates.sh"

# Link checks
node "$ROOT_DIR/scripts/link_check.js"

# Editor / Workspace smoke test (A48 / A50)
node "$ROOT_DIR/scripts/editor_smoke_test.js"
node "$ROOT_DIR/scripts/mcq_smoke_test.js"



# Regression guard — fails if any resolved issue is accidentally reverted
node "$ROOT_DIR/scripts/regression_guard.js"

# Optional: C# compile/test if dotnet is available in the environment.
if command -v dotnet >/dev/null 2>&1; then
  echo "dotnet detected; running C# build + tests..."
  dotnet build "$ROOT_DIR/backend/Codivium.Dashboard.csproj" -c Release
  dotnet test "$ROOT_DIR/backend/tests/Codivium.Dashboard.Tests.csproj" -c Release
else
  echo "dotnet not found; skipping C# build/tests."
fi

# Generate manifest
node "$ROOT_DIR/scripts/generate_manifest.js"

echo "All checks passed."
