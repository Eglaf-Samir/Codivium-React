// CodiviumAdaptiveEngine.cs
//
// The seven-step adaptive recommendation engine.
// Called by CodiviumAdaptiveEndpoints.GetAdaptiveState().
//
// Steps:
//   1. Receive session history (365-day window, pre-loaded by caller)
//   2. New-user detection → caller returns 404
//   3. Ring fills + drain state per category per difficulty
//   4. Session quality from most recent session
//   5. Recommendation engine — seven trigger types in priority order
//   6. templateVars population for the winning recommendation
//   7. Milestone detection
//
// All thresholds mirror AP_CONFIG in adaptive-practice.js.
// SubCategory comes from CodingSession.SubCategory (set at session storage time).

#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;

namespace Codivium.Adaptive
{
    // ══════════════════════════════════════════════════════════════════════════
    // Result types
    // ══════════════════════════════════════════════════════════════════════════

    public sealed class AdaptiveEngineResult
    {
        public bool                              IsNewUser          { get; init; }
        public string                            Mode               { get; init; } = "orientation";
        public int                               SessionCount       { get; init; }
        public int                               LastSessionDaysAgo { get; init; }
        public string                            LastSessionLabel   { get; init; } = "";
        public IReadOnlyList<AdaptiveCategoryDto>       Categories  { get; init; } = Array.Empty<AdaptiveCategoryDto>();
        public AdaptivePrimaryDto?                       Primary     { get; init; }
        public IReadOnlyList<AdaptiveAlternativeDto>     Alternatives { get; init; } = Array.Empty<AdaptiveAlternativeDto>();
        public AdaptiveMilestoneDto?                     Milestone   { get; init; }
        public IReadOnlyList<AdaptiveRecentSessionDto>   RecentSessions { get; init; } = Array.Empty<AdaptiveRecentSessionDto>();
        public AdaptiveSessionQualityDto?                SessionQuality { get; init; }

        public static AdaptiveEngineResult NewUser() => new() { IsNewUser = true, Mode = "orientation" };
    }

    // Internal ring computation state
    sealed class RingState
    {
        public int       CorrectAnswers { get; set; }
        public int       SessionCount   { get; set; }
        public DateTime  LastCorrectAt  { get; set; } = DateTime.MinValue;
        public double    Fill           { get; set; }   // 0–100, after drain applied
        public string    DrainState     { get; set; } = "normal"; // normal|draining|ready|gap|locked
        public string    StatusLabel    { get; set; } = "Not started";
        public double    RollingScore   { get; set; }  // rolling avg of last N sessions
        public int       RollingSessions { get; set; } // sessions counted in rolling window
    }

    // Flattened session for cross-type processing
    sealed class Session
    {
        public string   Category    { get; init; } = "";
        public string?  SubCategory { get; init; }
        public string   Difficulty  { get; init; } = "basic";
        public double   Score       { get; init; }
        public string   Type        { get; init; } = "mcq"; // "mcq" | "coding"
        public DateTime CompletedAt { get; init; }
        public int      Correct     { get; init; }
        public int      Total       { get; init; }
    }

    // Recommendation candidate produced by each trigger
    sealed class Candidate
    {
        public string                      Type        { get; init; } = "";
        public string                      TypeLabel   { get; init; } = "";
        public string                      CtaLabel    { get; init; } = "";
        public string                      CtaHref     { get; init; } = "";
        public string                      Headline    { get; init; } = "";
        public string                      Context     { get; init; } = "";
        public string                      Evidence    { get; init; } = "";
        public int                         EvidencePct { get; init; }
        public Dictionary<string, string>  TemplateVars { get; init; } = new();
        public string                      AltHeadline { get; init; } = "";
        public string                      AltSub      { get; init; } = "";
        public string                      AltSci      { get; init; } = "";
        public string                      AltType     { get; init; } = "teal"; // "teal"|"amber"
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Engine
    // ══════════════════════════════════════════════════════════════════════════

    public static class AdaptiveEngine
    {
        // ── Thresholds (mirror AP_CONFIG in adaptive-practice.js) ────────────
        const int    RingTarget             = 30;
        const double AdvancementScoreMin    = 70.0;
        const int    AdvancementSessionsMin = 5;

        const int    GraceDaysBasic        = 14;
        const int    GraceDaysIntermediate = 21;
        const int    GraceDaysAdvanced     = 28;
        const double SlowDrainPerDay       = 0.10;
        const double FastDrainPerDay       = 0.20;

        const int    ReEntryDays            = 7;
        const double WeaknessMinGapPct      = 50.0;
        const int    WeaknessMinCategories  = 3;
        const int    WeaknessMinQPerCat     = 5;
        const int    SpacedDaysSinceCorrect = 14;
        const int    SpacedMinCorrect       = 5;
        const double DiffProgMinScore       = 70.0;
        const int    DiffProgMinSessions    = 3;
        const double ModeSwitchMaxRatio     = 1.5;
        const int    ModeSwitchMinSessions  = 10;
        const double StretchMinScore        = 65.0;
        const double RecoveryDropPct        = 30.0;
        const int    RecoveryMaxAbsenceDays = 3;

        // ── Entry point ───────────────────────────────────────────────────────

        public static AdaptiveEngineResult Compute(
            string track,
            IReadOnlyList<CodiviumScoring.CodingSession> codingSessions,
            IReadOnlyList<CodiviumScoring.McqAttempt>    mcqAttempts,
            DateTimeOffset asOfUtc)
        {
            // Step 2 — new user
            if (!codingSessions.Any() && !mcqAttempts.Any())
                return AdaptiveEngineResult.NewUser();

            int totalSessions = codingSessions.Count + mcqAttempts.Count;
            string mode = totalSessions < 10 ? "building" : "full";

            // Flatten to unified session list, newest first
            var sessions = Flatten(codingSessions, mcqAttempts)
                           .OrderByDescending(s => s.CompletedAt)
                           .ToList();

            int daysAgo = sessions.Any()
                ? (int)(asOfUtc.UtcDateTime - sessions[0].CompletedAt).TotalDays
                : 999;

            // Step 3 — ring fills
            var rings = ComputeRings(sessions, asOfUtc);
            MarkGapState(rings);

            // Step 4 — session quality
            var quality = ComputeQuality(sessions);

            // Step 5+6 — recommendation engine
            var candidates = EvaluateTriggers(sessions, rings, daysAgo, track, asOfUtc);
            var primary     = candidates.ElementAtOrDefault(0);
            var alt1        = candidates.ElementAtOrDefault(1);
            var alt2        = candidates.ElementAtOrDefault(2);

            // Step 7 — milestone
            var milestone = CheckMilestone(totalSessions, rings, sessions, asOfUtc);

            return new AdaptiveEngineResult
            {
                IsNewUser          = false,
                Mode               = mode,
                SessionCount       = totalSessions,
                LastSessionDaysAgo = daysAgo,
                LastSessionLabel   = FormatDaysAgo(daysAgo),
                Categories         = BuildCategoryDtos(rings),
                Primary            = primary is null ? null : BuildPrimaryDto(primary, track),
                Alternatives       = BuildAlternativeDtos(new[] { alt1, alt2 }),
                Milestone          = milestone,
                RecentSessions     = sessions.Take(5).Select(ToRecentDto).ToList(),
                SessionQuality     = quality,
            };
        }

        // ── Step 3: Ring computation ──────────────────────────────────────────

        static Dictionary<string, Dictionary<string, RingState>> ComputeRings(
            List<Session> sessions, DateTimeOffset asOfUtc)
        {
            // rings[category][difficulty]
            var rings = new Dictionary<string, Dictionary<string, RingState>>(
                StringComparer.OrdinalIgnoreCase);

            void Ensure(string cat, string diff)
            {
                if (!rings.ContainsKey(cat))
                    rings[cat] = new Dictionary<string, RingState>(StringComparer.OrdinalIgnoreCase);
                if (!rings[cat].ContainsKey(diff))
                    rings[cat][diff] = new RingState();
            }

            foreach (var s in sessions)
            {
                if (string.IsNullOrWhiteSpace(s.Category)) continue;
                Ensure(s.Category, s.Difficulty);
                var ring = rings[s.Category][s.Difficulty];
                ring.CorrectAnswers += s.Correct;
                ring.SessionCount++;
                if (s.Correct > 0 && s.CompletedAt > ring.LastCorrectAt)
                    ring.LastCorrectAt = s.CompletedAt;
            }

            // Rolling score: last AdvancementSessionsMin sessions per category/difficulty
            foreach (var catKv in rings)
            {
                foreach (var diffKv in catKv.Value)
                {
                    var recent = sessions
                        .Where(s => s.Category.Equals(catKv.Key, StringComparison.OrdinalIgnoreCase)
                                 && s.Difficulty.Equals(diffKv.Key, StringComparison.OrdinalIgnoreCase))
                        .Take(AdvancementSessionsMin)
                        .ToList();
                    if (recent.Any())
                    {
                        diffKv.Value.RollingScore    = recent.Average(s => s.Score);
                        diffKv.Value.RollingSessions = recent.Count;
                    }
                }
            }

            // Compute fill and apply drain
            foreach (var catKv in rings)
            {
                foreach (var diffKv in catKv.Value)
                {
                    var ring = diffKv.Value;
                    double rawFill = Math.Min(100.0, ring.CorrectAnswers / (double)RingTarget * 100.0);

                    // Drain
                    if (ring.LastCorrectAt != DateTime.MinValue)
                    {
                        int graceDays = GraceDays(diffKv.Key);
                        double daysSinceLast = (asOfUtc.UtcDateTime - ring.LastCorrectAt).TotalDays;
                        if (daysSinceLast > graceDays)
                        {
                            double pastGrace = daysSinceLast - graceDays;
                            double slowDays  = Math.Min(pastGrace, 7);
                            double fastDays  = Math.Max(0, pastGrace - 7);
                            double drain     = (slowDays * SlowDrainPerDay + fastDays * FastDrainPerDay) * rawFill;
                            rawFill          = Math.Max(0, rawFill - drain);
                            ring.DrainState  = "draining";
                        }
                    }

                    ring.Fill = rawFill;

                    // Status label
                    (ring.DrainState, ring.StatusLabel) = ring.Fill >= 100
                        ? ("ready",    "Ready to advance")
                        : ring.DrainState == "draining"
                        ? ("draining", "Review due")
                        : ring.CorrectAnswers == 0
                        ? ("locked",   "Not started")
                        : ring.Fill >= 60
                        ? ("normal",   "In progress")
                        : ("normal",   "Just started");
                }
            }

            return rings;
        }

        static void MarkGapState(Dictionary<string, Dictionary<string, RingState>> rings)
        {
            // Find the category with the lowest fill at basic difficulty —
            // mark it as the gap category
            var basicFills = rings
                .Where(c => c.Value.ContainsKey("basic"))
                .Select(c => (cat: c.Key, fill: c.Value["basic"].Fill))
                .ToList();

            if (basicFills.Count < WeaknessMinCategories) return;

            double maxFill = basicFills.Max(x => x.fill);
            var gapCat     = basicFills
                .Where(x => maxFill - x.fill >= WeaknessMinGapPct)
                .OrderBy(x => x.fill)
                .FirstOrDefault();

            if (gapCat.cat is not null && rings[gapCat.cat].ContainsKey("basic"))
                rings[gapCat.cat]["basic"].DrainState  = "gap";
                rings[gapCat.cat]["basic"].StatusLabel = "Priority gap";
        }

        static int GraceDays(string difficulty) => difficulty switch
        {
            "intermediate" => GraceDaysIntermediate,
            "advanced"     => GraceDaysAdvanced,
            _              => GraceDaysBasic,
        };

        // ── Step 4: Session quality ───────────────────────────────────────────

        static AdaptiveSessionQualityDto? ComputeQuality(List<Session> sessions)
        {
            if (!sessions.Any()) return null;
            var last = sessions[0];

            // Score as proxy for accuracy; simplified — real accuracy needs per-answer data
            double accuracy = last.Total > 0 ? (double)last.Correct / last.Total * 100.0 : last.Score;

            string level = accuracy switch
            {
                >= 90 => "Fluent",
                >= 80 => "Proficient",
                >= 70 => "Consolidation",
                _     => "Foundation",
            };

            double pct = level switch
            {
                "Fluent"        => Math.Min(100, (accuracy - 90) / 10.0 * 100),
                "Proficient"    => Math.Min(100, (accuracy - 80) / 10.0 * 100),
                "Consolidation" => Math.Min(100, (accuracy - 70) / 10.0 * 100),
                _               => Math.Min(100, accuracy / 60.0 * 100),
            };

            var levels = new[] { "Foundation", "Consolidation", "Proficient", "Fluent" }
                .Select(n => new AdaptiveQualityLevelDto
                {
                    Name      = n,
                    Pct       = n == level ? (int)pct : n == "Foundation" || n == "Consolidation" && level is "Proficient" or "Fluent" || n == "Proficient" && level == "Fluent" ? 100 : 0,
                    IsCurrent = n == level,
                })
                .ToList();

            return new AdaptiveSessionQualityDto { Level = level, Levels = levels };
        }

        // ── Step 5: Recommendation engine ────────────────────────────────────

        static List<Candidate> EvaluateTriggers(
            List<Session> sessions,
            Dictionary<string, Dictionary<string, RingState>> rings,
            int daysAgo,
            string track,
            DateTimeOffset asOfUtc)
        {
            var candidates = new List<Candidate?>();

            candidates.Add(TryReEntry(sessions, rings, daysAgo, track));
            candidates.Add(TryWeaknessSpotlight(sessions, rings, track));
            candidates.Add(TrySpacedReview(sessions, rings, track, asOfUtc));
            candidates.Add(TryDifficultyProgression(sessions, rings, track));
            candidates.Add(TryModeSwitch(sessions, rings, track));
            candidates.Add(TryStretch(sessions, rings, track));
            candidates.Add(TryRecovery(sessions, rings, daysAgo, track));

            return candidates.Where(c => c is not null).Select(c => c!).ToList();
        }

        // 1. Re-entry
        static Candidate? TryReEntry(
            List<Session> sessions,
            Dictionary<string, Dictionary<string, RingState>> rings,
            int daysAgo, string track)
        {
            if (daysAgo < ReEntryDays) return null;

            // Target the highest-fill draining category
            var target = rings
                .Where(c => c.Value.Any(d => d.Value.DrainState == "draining"))
                .OrderByDescending(c => c.Value.Values.Max(r => r.Fill))
                .FirstOrDefault();

            string cat  = target.Key ?? sessions.FirstOrDefault()?.Category ?? "your last category";
            string diff = "basic";
            int    evidence = Math.Min(95, 70 + daysAgo * 2);

            return new Candidate
            {
                Type        = "re_entry",
                TypeLabel   = "Re-entry — restoring momentum",
                CtaLabel    = $"Start recovery session",
                CtaHref     = BuildHref(track, cat, diff, "reentry"),
                Headline    = $"Welcome back — {daysAgo} days away. A short session now recovers what matters most.",
                Context     = $"The forgetting curve has been working since your last session. A targeted retrieval session on {cat} now is the most efficient thing you can do to restore that knowledge.",
                Evidence    = $"High signal — absence duration is unambiguous ({daysAgo} days)",
                EvidencePct = evidence,
                TemplateVars = new() { ["category"] = cat, ["n"] = daysAgo.ToString() },
                AltHeadline = $"Re-entry: {cat}",
                AltSub      = $"You have been away for {daysAgo} days. A short session on {cat} reactivates the material before further decay.",
                AltSci      = "Spaced retrieval: relearning after a gap is faster than first learning but requires active retrieval to arrest decay.",
                AltType     = "amber",
            };
        }

        // 2. Weakness spotlight
        static Candidate? TryWeaknessSpotlight(
            List<Session> sessions,
            Dictionary<string, Dictionary<string, RingState>> rings,
            string track)
        {
            var attempted = rings.Where(c =>
                    c.Value.Values.Any(r => r.SessionCount >= 1))
                .ToList();

            if (attempted.Count < WeaknessMinCategories) return null;

            var fills = attempted
                .Select(c => (cat: c.Key,
                              fill: c.Value.ContainsKey("basic") ? c.Value["basic"].Fill : 0,
                              questions: c.Value.Values.Sum(r => r.CorrectAnswers)))
                .Where(x => x.questions >= WeaknessMinQPerCat)
                .ToList();

            if (fills.Count < WeaknessMinCategories) return null;

            double maxFill = fills.Max(x => x.fill);
            var worst = fills.OrderBy(x => x.fill).First();
            double gap = maxFill - worst.fill;

            if (gap < WeaknessMinGapPct) return null;

            string best = fills.OrderByDescending(x => x.fill).First().cat;
            int evidence = Math.Min(90, 60 + (int)gap / 2);

            return new Candidate
            {
                Type         = "weakness_spotlight",
                TypeLabel    = "Weakness spotlight — biggest gap",
                CtaLabel     = $"Practice {worst.cat} now",
                CtaHref      = BuildHref(track, worst.cat, "basic", "weakness"),
                Headline     = $"Your {worst.cat} knowledge has the most room to grow.",
                Context      = $"You're scoring {(int)worst.fill}% on {worst.cat} — {(int)gap} points below your average. That gap is where focused effort returns the most, right now.",
                Evidence     = $"Strong signal — {fills.Count} categories, {(int)gap}pt gap",
                EvidencePct  = evidence,
                TemplateVars = new() {
                    ["category"] = worst.cat,
                    ["score"]    = ((int)worst.fill).ToString(),
                    ["gap"]      = ((int)gap).ToString(),
                    ["n"]        = fills.Count.ToString(),
                },
                AltHeadline  = $"Weakness: {worst.cat}",
                AltSub       = $"{worst.cat} is {(int)gap}% below your strongest category ({best}). A focused session now closes the gap fastest.",
                AltSci       = "Deliberate practice produces the fastest improvement when effort targets the area of greatest weakness.",
                AltType      = "amber",
            };
        }

        // 3. Spaced review
        static Candidate? TrySpacedReview(
            List<Session> sessions,
            Dictionary<string, Dictionary<string, RingState>> rings,
            string track,
            DateTimeOffset asOfUtc)
        {
            var due = rings
                .SelectMany(c => c.Value.Select(d => new
                {
                    Cat      = c.Key,
                    Diff     = d.Key,
                    Ring     = d.Value,
                    DaysSince = d.Value.LastCorrectAt == DateTime.MinValue ? 999
                                : (int)(asOfUtc.UtcDateTime - d.Value.LastCorrectAt).TotalDays,
                }))
                .Where(x => x.DaysSince >= SpacedDaysSinceCorrect
                         && x.Ring.CorrectAnswers >= SpacedMinCorrect)
                .OrderByDescending(x => x.DaysSince)
                .FirstOrDefault();

            if (due is null) return null;

            return new Candidate
            {
                Type         = "spaced_review",
                TypeLabel    = "Spaced review — optimal recall window",
                CtaLabel     = $"Review {due.Cat} now",
                CtaHref      = BuildHref(track, due.Cat, due.Diff, "spaced"),
                Headline     = $"{due.Cat} is due for review — {due.DaysSince} days since your last session.",
                Context      = $"The optimal review window for {due.Cat} is open now. Reviewing at this point produces more durable memory than reviewing earlier or later.",
                Evidence     = $"Clear signal — {due.DaysSince} days since last correct answer",
                EvidencePct  = Math.Min(88, 60 + due.DaysSince),
                TemplateVars = new() {
                    ["category"] = due.Cat,
                    ["n"]        = due.DaysSince.ToString(),
                },
                AltHeadline  = $"Spaced review: {due.Cat}",
                AltSub       = $"The review window for {due.Cat} is open — {due.DaysSince} days since your last correct answers.",
                AltSci       = "Spaced repetition: reviewing at the point of near-forgetting produces more durable memory than reviewing earlier or later.",
                AltType      = "teal",
            };
        }

        // 4. Difficulty progression
        static Candidate? TryDifficultyProgression(
            List<Session> sessions,
            Dictionary<string, Dictionary<string, RingState>> rings,
            string track)
        {
            foreach (var (nextDiff, currDiff) in new[] { ("advanced","intermediate"), ("intermediate","basic") })
            {
                var ready = rings
                    .Where(c => c.Value.ContainsKey(currDiff)
                             && c.Value[currDiff].Fill >= 99.9
                             && c.Value[currDiff].RollingScore >= DiffProgMinScore
                             && c.Value[currDiff].RollingSessions >= DiffProgMinSessions)
                    .OrderByDescending(c => c.Value[currDiff].RollingScore)
                    .FirstOrDefault();

                if (ready.Key is null) continue;

                string cat       = ready.Key;
                double rollingAvg = ready.Value[currDiff].RollingScore;
                string currLabel  = Capitalise(currDiff);
                string nextLabel  = Capitalise(nextDiff);

                return new Candidate
                {
                    Type         = "difficulty_progression",
                    TypeLabel    = "Difficulty progression — level up",
                    CtaLabel     = $"Start {cat} {nextLabel}",
                    CtaHref      = BuildHref(track, cat, nextDiff, "progression"),
                    Headline     = $"{cat} {currLabel} is complete. It's time to move to {nextLabel}.",
                    Context      = $"Your ring for {cat} {currLabel} is full and your rolling average across the last {DiffProgMinSessions} sessions is {(int)rollingAvg}% — above the {(int)DiffProgMinScore}% threshold for advancement.",
                    Evidence     = $"Clear signal — ring full, rolling average {(int)rollingAvg}%",
                    EvidencePct  = Math.Min(95, (int)rollingAvg),
                    TemplateVars = new() {
                        ["category"]       = cat,
                        ["difficulty"]     = currLabel,
                        ["nextDifficulty"] = nextLabel,
                    },
                    AltHeadline  = $"Advance {cat} to {nextLabel}",
                    AltSub       = $"{cat} {currLabel} ring is full with a {(int)rollingAvg}% rolling average. {nextLabel} is the next step.",
                    AltSci       = "Zone of proximal development: the most productive learning happens just beyond current ability.",
                    AltType      = "teal",
                };
            }

            return null;
        }

        // 5. Mode switch (MCQ → coding or coding → MCQ)
        static Candidate? TryModeSwitch(
            List<Session> sessions,
            Dictionary<string, Dictionary<string, RingState>> rings,
            string track)
        {
            if (sessions.Count < ModeSwitchMinSessions) return null;

            var recent = sessions.Take(ModeSwitchMinSessions).ToList();
            int mcqCount    = recent.Count(s => s.Type == "mcq");
            int codingCount = recent.Count(s => s.Type == "coding");
            if (codingCount == 0 && mcqCount == 0) return null;

            string dominant, other;
            double ratio;

            if (codingCount == 0)
            { dominant = "MCQ"; other = "coding"; ratio = mcqCount; }
            else if (mcqCount == 0)
            { dominant = "coding"; other = "MCQ"; ratio = codingCount; }
            else
            {
                ratio    = Math.Max((double)mcqCount / codingCount, (double)codingCount / mcqCount);
                dominant = mcqCount >= codingCount ? "MCQ" : "coding";
                other    = dominant == "MCQ"       ? "coding" : "MCQ";
            }

            if (ratio < ModeSwitchMaxRatio) return null;

            string activeCat = recent.GroupBy(s => s.Category)
                               .OrderByDescending(g => g.Count())
                               .FirstOrDefault()?.Key ?? "";

            string href = other == "coding"
                ? $"../menu-page.html?track={track}&category={Uri.EscapeDataString(activeCat)}&difficulty=basic&source=adaptive&type=modeswitch"
                : BuildHref(track, activeCat, "basic", "modeswitch");

            return new Candidate
            {
                Type         = "mode_switch",
                TypeLabel    = "Mode switch — change practice format",
                CtaLabel     = other == "coding" ? $"Try a {activeCat} exercise" : $"Try {activeCat} MCQ",
                CtaHref      = href,
                Headline     = $"You've been doing {dominant} for {(int)ratio}x more sessions than {other}. Switch now.",
                Context      = $"Your last {ModeSwitchMinSessions} sessions have been {mcqCount} MCQ and {codingCount} coding. {(dominant == "MCQ" ? "MCQ builds recognition. Coding exercises build the procedural fluency that MCQ cannot develop." : "Coding builds fluency. MCQ reinforces the declarative knowledge base that fluency draws on.")}",
                Evidence     = $"Moderate signal — {(int)ratio}:1 {dominant}:{other} ratio",
                EvidencePct  = Math.Min(75, 50 + (int)(ratio * 5)),
                TemplateVars = new() {
                    ["dominantMode"] = dominant,
                    ["otherMode"]    = other,
                    ["ratio"]        = ((int)ratio).ToString(),
                    ["category"]     = activeCat,
                },
                AltHeadline  = $"Switch to {other}",
                AltSub       = $"Your ratio of {dominant} to {other} sessions is {(int)ratio}:1. A {other} session on {activeCat} would restore balance.",
                AltSci       = "Learning science distinguishes declarative knowledge (MCQ) from procedural fluency (coding). Both are required for durable skill.",
                AltType      = "amber",
            };
        }

        // 6. Stretch
        static Candidate? TryStretch(
            List<Session> sessions,
            Dictionary<string, Dictionary<string, RingState>> rings,
            string track)
        {
            if (!rings.Any()) return null;

            var attempted = rings.Where(c => c.Value.Values.Any(r => r.SessionCount > 0)).ToList();
            if (!attempted.Any()) return null;

            double overallScore = attempted
                .SelectMany(c => c.Value.Values)
                .Where(r => r.SessionCount > 0)
                .Average(r => r.Fill);

            if (overallScore < StretchMinScore) return null;

            // Find strongest category
            var strongest = attempted
                .OrderByDescending(c => c.Value.Values.Max(r => r.Fill))
                .First();

            // Find untouched categories
            var untouched = rings
                .Where(c => c.Value.Values.All(r => r.SessionCount == 0))
                .ToList();
            if (!untouched.Any()) return null;

            // Use SubCategory adjacency: find untouched category that shares
            // the most SubCategory values with the user's strongest category
            var strongestSubCats = sessions
                .Where(s => s.Category.Equals(strongest.Key, StringComparison.OrdinalIgnoreCase)
                         && !string.IsNullOrEmpty(s.SubCategory))
                .Select(s => s.SubCategory!)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            // Map untouched category names to sub-category adjacency score
            // (populated from session data of other users or exercise metadata if available)
            // Fallback: pick the untouched category with the most exercises (proxy = most sessions
            // by other users in the same track — not available here, so use first alphabetically)
            string newCat = untouched
                .OrderByDescending(c =>
                {
                    // Score adjacency by how many known sub-categories overlap
                    // with those seen in the strongest category's sessions
                    if (!strongestSubCats.Any()) return 0;
                    var targetSubs = sessions
                        .Where(s => s.Category.Equals(c.Key, StringComparison.OrdinalIgnoreCase))
                        .Select(s => s.SubCategory ?? "")
                        .Distinct(StringComparer.OrdinalIgnoreCase)
                        .ToList();
                    return targetSubs.Count(sub => strongestSubCats.Contains(sub));
                })
                .ThenBy(c => c.Key)
                .First().Key;

            return new Candidate
            {
                Type         = "stretch",
                TypeLabel    = "Stretch — expand your range",
                CtaLabel     = $"Try {newCat}",
                CtaHref      = BuildHref(track, newCat, "basic", "stretch"),
                Headline     = $"You've mastered {strongest.Key}. {newCat} uses the same core mental models.",
                Context      = $"Your {strongest.Key} score is strong at {(int)strongest.Value.Values.Max(r => r.Fill)}%. {newCat} builds on related concepts and is the natural next frontier.",
                Evidence     = $"Moderate signal — strong foundations, {newCat} adjacent",
                EvidencePct  = 72,
                TemplateVars = new() {
                    ["currentCategory"] = strongest.Key,
                    ["newCategory"]     = newCat,
                },
                AltHeadline  = $"Try {newCat}",
                AltSub       = $"Your {strongest.Key} foundations make {newCat} a productive next step — shared mental models reduce the cold-start difficulty.",
                AltSci       = "Transfer of learning: prior mastery in adjacent domains reduces acquisition time for new material.",
                AltType      = "teal",
            };
        }

        // 7. Recovery
        static Candidate? TryRecovery(
            List<Session> sessions,
            Dictionary<string, Dictionary<string, RingState>> rings,
            int daysAgo,
            string track)
        {
            if (daysAgo > RecoveryMaxAbsenceDays) return null;
            if (!sessions.Any()) return null;

            var lastSession = sessions[0];

            // Category rolling average (last 5 sessions, same category)
            var catSessions = sessions
                .Where(s => s.Category.Equals(lastSession.Category, StringComparison.OrdinalIgnoreCase))
                .Skip(1)  // exclude the last session itself
                .Take(5)
                .ToList();

            if (!catSessions.Any()) return null;

            double average = catSessions.Average(s => s.Score);
            double drop    = average - lastSession.Score;

            if (drop < RecoveryDropPct) return null;

            return new Candidate
            {
                Type         = "recovery",
                TypeLabel    = "Recovery — rebound from a tough session",
                CtaLabel     = $"Retry {lastSession.Category}",
                CtaHref      = BuildHref(track, lastSession.Category, lastSession.Difficulty, "recovery"),
                Headline     = $"That session was a tough one — and that's useful information.",
                Context      = $"Your {lastSession.Category} score was {(int)drop}% below your average of {(int)average}%. A poor session is the most diagnostic event in deliberate practice.",
                Evidence     = $"Clear signal — {(int)drop}pt drop below {(int)average}% average",
                EvidencePct  = Math.Min(88, 60 + (int)drop),
                TemplateVars = new() {
                    ["category"] = lastSession.Category,
                    ["gap"]      = ((int)drop).ToString(),
                    ["average"]  = ((int)average).ToString(),
                },
                AltHeadline  = $"Recover: {lastSession.Category}",
                AltSub       = $"Your last session scored {(int)drop}% below your average on {lastSession.Category}. A targeted recovery session closes the gap.",
                AltSci       = "Errors are the most information-rich events in deliberate practice. A recovery session directly after a poor one produces faster improvement than moving on.",
                AltType      = "amber",
            };
        }

        // ── Step 7: Milestones ────────────────────────────────────────────────

        static AdaptiveMilestoneDto? CheckMilestone(
            int sessionCount,
            Dictionary<string, Dictionary<string, RingState>> rings,
            List<Session> sessions,
            DateTimeOffset asOfUtc)
        {
            // First session
            if (sessionCount == 1)
                return new AdaptiveMilestoneDto
                {
                    Type    = "first_session",
                    Label   = "First session complete",
                    Context = "You've completed your first session. Your profile has started building.",
                };

            // First ring complete
            var firstComplete = rings
                .SelectMany(c => c.Value.Select(d => new { Cat = c.Key, Diff = d.Key, d.Value.Fill }))
                .Where(x => x.Fill >= 100)
                .OrderBy(x => x.Diff)
                .FirstOrDefault();

            if (firstComplete is not null)
            {
                string next = firstComplete.Diff == "basic" ? "Intermediate"
                            : firstComplete.Diff == "intermediate" ? "Advanced"
                            : "—";
                return new AdaptiveMilestoneDto
                {
                    Type           = "first_ring",
                    Label          = "First ring complete",
                    Category       = firstComplete.Cat,
                    Difficulty     = Capitalise(firstComplete.Diff),
                    NextDifficulty = next,
                    Context        = $"{firstComplete.Cat} {Capitalise(firstComplete.Diff)} is now full. {(next == "—" ? "" : next + " is unlocked.")}",
                };
            }

            // Ten sessions
            if (sessionCount == 10)
                return new AdaptiveMilestoneDto
                {
                    Type    = "ten_sessions",
                    Label   = "10 sessions in",
                    Context = "You have completed 10 sessions. Full adaptive guidance is now active.",
                };

            // First full week — 7 consecutive calendar days with at least one session
            if (sessions.Count >= 7)
            {
                var dates = sessions
                    .Select(s => s.CompletedAt.Date)
                    .Distinct()
                    .OrderDescending()
                    .ToList();

                int streak = 1;
                for (int i = 1; i < dates.Count && streak < 7; i++)
                {
                    if ((dates[i - 1] - dates[i]).TotalDays == 1) streak++;
                    else break;
                }

                if (streak >= 7)
                    return new AdaptiveMilestoneDto
                    {
                        Type    = "first_week",
                        Label   = "First full week",
                        Context = "Seven consecutive days of practice. Habit formation confirmed.",
                    };
            }

            return null;
        }

        // ── DTO builders ──────────────────────────────────────────────────────

        static IReadOnlyList<AdaptiveCategoryDto> BuildCategoryDtos(
            Dictionary<string, Dictionary<string, RingState>> rings)
        {
            return rings.Select(c =>
            {
                var basic = c.Value.TryGetValue("basic",        out var b) ? b : null;
                var inter = c.Value.TryGetValue("intermediate", out var i) ? i : null;
                var adv   = c.Value.TryGetValue("advanced",     out var a) ? a : null;

                var bestRing  = basic ?? inter ?? adv ?? new RingState();
                var bestDiff  = basic ?? inter ?? adv;

                return new AdaptiveCategoryDto
                {
                    Name   = c.Key,
                    Fill   = (int)(bestRing.Fill),
                    Diff   = new[] {
                        basic != null && basic.Fill  >= 100 ? 1 : 0,
                        inter != null && inter.Fill  >= 100 ? 1 : 0,
                        adv   != null && adv.Fill    >= 100 ? 1 : 0,
                    },
                    State  = bestRing.DrainState,
                    Status = bestRing.StatusLabel,
                };
            }).ToList();
        }

        static AdaptivePrimaryDto BuildPrimaryDto(Candidate c, string track)
            => new AdaptivePrimaryDto
            {
                Type         = c.Type,
                TypeLabel    = c.TypeLabel,
                Headline     = c.Headline,
                Context      = c.Context,
                Evidence     = c.Evidence,
                EvidencePct  = c.EvidencePct,
                SciShort     = DefaultSciShort(c.Type),
                SciLong      = DefaultSciLong(c.Type),
                CtaLabel     = c.CtaLabel,
                CtaHref      = c.CtaHref,
                TemplateVars = c.TemplateVars,
            };

        static IReadOnlyList<AdaptiveAlternativeDto> BuildAlternativeDtos(
            IEnumerable<Candidate?> candidates)
        {
            return candidates
                .Where(c => c is not null)
                .Select(c => new AdaptiveAlternativeDto
                {
                    Type      = c!.AltType,
                    TypeLabel = c.TypeLabel,
                    Headline  = c.AltHeadline,
                    Sub       = c.AltSub,
                    Sci       = c.AltSci,
                    Cta       = c.CtaLabel + " →",
                    Href      = c.CtaHref,
                })
                .ToList();
        }

        static AdaptiveRecentSessionDto ToRecentDto(Session s) => new()
        {
            Cat   = s.Category,
            Score = $"{(int)s.Score}%",
            State = s.Score >= 70 ? "correct" : s.Score >= 50 ? "partial" : "peeked",
        };

        // ── Helpers ───────────────────────────────────────────────────────────

        static List<Session> Flatten(
            IReadOnlyList<CodiviumScoring.CodingSession> coding,
            IReadOnlyList<CodiviumScoring.McqAttempt> mcq)
        {
            var list = new List<Session>();

            foreach (var s in coding)
            {
                string cat  = s.CategoryId ?? s.CategoryLegacy ?? "";
                if (string.IsNullOrWhiteSpace(cat)) continue;
                var lastAttempt = s.Attempts?.LastOrDefault();
                int correct = lastAttempt?.UnitTestsPassed ?? 0;
                double score = s.UnitTestsTotal > 0
                    ? (double)correct / s.UnitTestsTotal * 100.0
                    : 0;
                list.Add(new Session
                {
                    Category    = cat,
                    SubCategory = s.SubCategory,
                    Difficulty  = NormaliseDifficulty(s.Difficulty),
                    Score       = score,
                    Type        = "coding",
                    CompletedAt = s.CompletedAtUtc ?? s.StartedAtUtc ?? DateTime.MinValue,
                    Correct     = correct,
                    Total       = s.UnitTestsTotal,
                });
            }

            foreach (var m in mcq)
            {
                string cat = m.CategoryId ?? m.CategoryLegacy ?? "";
                if (string.IsNullOrWhiteSpace(cat)) continue;
                list.Add(new Session
                {
                    Category    = cat,
                    SubCategory = null,
                    Difficulty  = NormaliseDifficulty(m.Difficulty),
                    Score       = m.ScorePercent ?? m.PercentLegacy ?? 0,
                    Type        = "mcq",
                    CompletedAt = m.CompletedAtUtc ?? m.TakenAtUtcLegacy ?? DateTime.MinValue,
                    Correct     = m.Correct ?? 0,
                    Total       = m.TotalQuestions ?? 0,
                });
            }

            return list;
        }

        static string NormaliseDifficulty(string? d) => d?.ToLowerInvariant() switch
        {
            "1" or "basic"        => "basic",
            "2" or "intermediate" => "intermediate",
            "3" or "advanced"     => "advanced",
            _                     => "basic",
        };

        static string Capitalise(string s)
            => string.IsNullOrEmpty(s) ? s : char.ToUpper(s[0]) + s[1..];

        static string FormatDaysAgo(int days) => days switch
        {
            0     => "today",
            1     => "yesterday",
            <= 6  => $"{days} days ago",
            7     => "a week ago",
            <= 13 => $"{days} days ago",
            14    => "two weeks ago",
            _     => $"{days} days ago",
        };

        static string BuildHref(string track, string category, string difficulty, string type)
        {
            string catEnc  = Uri.EscapeDataString(category);
            string diffEnc = Uri.EscapeDataString(difficulty);
            return $"../mcq-parent.html?categories={catEnc}&difficulty={diffEnc}&count=10&source=adaptive&type={type}";
        }

        // Default scientific copy for each recommendation type
        static string DefaultSciShort(string type) => type switch
        {
            "re_entry"              => "Retrieval practice at the point of near-forgetting produces significantly more durable memory than re-studying the same material.",
            "weakness_spotlight"    => "Deliberate practice produces the fastest improvement when effort targets the specific area of greatest weakness.",
            "spaced_review"         => "Spaced repetition: reviewing at the point of near-forgetting produces more durable memory than reviewing earlier or later.",
            "difficulty_progression"=> "Zone of proximal development: the optimal learning zone is just beyond current capability — not too easy, not too hard.",
            "mode_switch"           => "Learning science distinguishes declarative knowledge (MCQ) from procedural fluency (coding exercises). Both are required.",
            "stretch"               => "Transfer of learning: prior mastery in adjacent domains reduces acquisition time for new material.",
            "recovery"              => "Errors are the most information-rich events in deliberate practice. A recovery session directly after a poor one produces faster improvement.",
            _                       => "",
        };

        static string DefaultSciLong(string type) => type switch
        {
            "re_entry"              => "Hermann Ebbinghaus demonstrated in 1885 — and hundreds of subsequent studies have confirmed — that memories weaken exponentially without retrieval practice. The good news: relearning after a gap is always faster than first learning. A 10-minute retrieval session now is worth more than an hour after another week away.",
            "weakness_spotlight"    => "Anders Ericsson's research on expert performance found consistently that experts spend disproportionate time on their weakest areas. The gap in your profile is the clearest signal your data can give. Spending practice time on strengths feels productive but produces little measurable improvement. The uncomfortable sessions on weaker material are the ones that produce growth.",
            "spaced_review"         => "The spacing effect is one of the most replicated findings in memory research. Reviewing material at increasing intervals — just before you would forget it — produces retention that is significantly more durable than massed practice. The timing of review matters as much as the review itself.",
            "difficulty_progression"=> "Vygotsky's Zone of Proximal Development describes the region between what a learner can do independently and what they can do with challenge. Too easy and there is no growth stimulus. Too hard and performance collapses. The 70% advancement threshold exists precisely to identify when a learner is in the optimal zone.",
            "mode_switch"           => "Learning science distinguishes two types of knowledge: declarative (recognising that something is correct) and procedural (being able to produce it from scratch). MCQ develops the first. Coding exercises develop the second. Both are required for genuine competence — neither alone is sufficient.",
            "stretch"               => "Transfer of learning research shows that skills and mental models built in one area reduce acquisition time in related areas. A learner with strong foundations in their current category has already built the mental scaffolding that adjacent concepts hang on. Starting there is faster than starting from zero.",
            "recovery"              => "Research on deliberate practice shows that poor sessions are not failures — they are the highest-information events in a practice sequence. They reveal exactly which sub-concepts have not yet consolidated. A targeted recovery session immediately after a poor performance produces faster improvement than moving on to new material.",
            _                       => "",
        };
    }
}
